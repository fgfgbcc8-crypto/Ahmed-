# لُغَتي — تعلّم الإنجليزية بالعربية

تطبيق ويب متكامل لتعلّم اللغة الإنجليزية للمتحدثين بالعربية، مبني بـ **Next.js (App Router)** و **PostgreSQL** عبر **Drizzle ORM**.

> مصمّم ككرّاسة مدرسية: ورق كريمي، حبر أزرق داكن، وتصحيحات بالقلم الأحمر.

## المحتوى

| القسم | ما يحتويه |
| --- | --- |
| **الغلاف** | مقدمة المقرر، فهرس الفصول الستة، وخطة الدراسة اليومية |
| **المفردات** | 30 بطاقة مفردة في 6 فصول (المطعم، المطار، الأفعال، العمل، المشاعر، اليوميات) — البطاقة تنقلب لتكشف المعنى والنطق والمثال |
| **القواعد** | 6 دروس (المضارع البسيط، المضارع المستمر، الماضي البسيط، will vs going to، جمع الأسماء، حروف الجر) مع «خطأ شائع» في كل درس |
| **الاختبار** | 12 سؤالًا مع تصحيح فوري وشرح، وحفظ النتيجة في قاعدة البيانات |

## التشغيل محليًا

```bash
# 1) ثبّت الاعتماديات
npm install

# 2) أنشئ ملف البيئة وضع رابط قاعدة البيانات فيه
cp .env.example .env

# 3) أرسل الجداول إلى قاعدة البيانات
npx drizzle-kit push

# 4) شغّل الخادم
npm run dev
```

ثم افتح [http://localhost:3000](http://localhost:3000).

> المحتوى الدراسي يُزرع تلقائيًا في قاعدة البيانات عند أول طلب (idempotent) — لا تحتاج إلى أمر إضافي.

## رفع المشروع على GitHub

```bash
git init
git add .
git commit -m "Lughaty - English learning app for Arabic speakers"
git branch -M main
git remote add origin https://github.com/USERNAME/lughaty.git
git push -u origin main
```

## النشر على Vercel

1. ادخل إلى [vercel.com](https://vercel.com) واختر **Add New → Project**.
2. استورد المستودع الذي أنشأته للتو.
3. أضف متغيّر البيئة `DATABASE_URL` (من Neon أو Supabase أو أي مزوّد PostgreSQL).
4. اضغط **Deploy** — وسينشئ Vercel المشروع ويبنيه تلقائيًا مع كل عملية push.

## متغيّرات البيئة

| المتغيّر | الوصف |
| --- | --- |
| `DATABASE_URL` | رابط اتصال PostgreSQL، مثل `postgresql://user:pass@host:5432/db` |

## الواجهات البرمجية

| المسار | الطريقة | الوظيفة |
| --- | --- | --- |
| `/api/health` | `GET` | فحص اتصال قاعدة البيانات |
| `/api/progress?learner=ID` | `GET` | إحصاءات المتعلّم (الكلمات المتقنة، أفضل نتيجة، عدد المحاولات) |
| `/api/progress` | `POST` | حفظ تقدّم كلمة `{ learnerId, wordId, status }` أو نتيجة اختبار `{ learnerId, score, total }` |

## التقنيات

- **Next.js 16** — App Router، خادم + عميل
- **Drizzle ORM + PostgreSQL** — المخطط في `src/db/schema.ts`
- **Tailwind CSS v4** — نظام الألوان والخطوط في `src/app/globals.css`
- **Framer Motion** — حركة انقلاب البطاقات ودخول الأقسام

## هيكل المشروع

```
src/
  app/
    page.tsx            # الغلاف
    vocabulary/page.tsx # بطاقات المفردات
    lessons/page.tsx    # دروس القواعد
    quiz/page.tsx       # الاختبار
    api/
      health/route.ts
      progress/route.ts
  components/           # SiteHeader · SiteFooter · Flashcards · Quiz · Reveal
  db/
    schema.ts           # جداول Drizzle
    seed.ts             # المحتوى الدراسي والزراعة التلقائية
  lib/                  # learner.ts · stats.ts
```
