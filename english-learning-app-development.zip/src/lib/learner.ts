const KEY = "lughaty-learner-id";

export function getLearnerId(): string {
  if (typeof window === "undefined") return "guest";
  try {
    const existing = window.localStorage.getItem(KEY);
    if (existing) return existing;
    const created = `l-${Math.random().toString(36).slice(2, 10)}`;
    window.localStorage.setItem(KEY, created);
    return created;
  } catch {
    return "guest";
  }
}
