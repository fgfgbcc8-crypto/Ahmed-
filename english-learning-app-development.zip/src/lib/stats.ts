import { sql } from "drizzle-orm";
import { db } from "@/db";
import { categories, lessons, quizQuestions, words } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";

export type CourseStats = {
  words: number;
  lessons: number;
  questions: number;
  categories: number;
};

/** Content counts used by the cover page and the footer band. */
export async function getCourseStats(): Promise<CourseStats> {
  await ensureSeeded();
  const [wordCount] = await db
    .select({ count: sql<number>`count(*)` })
    .from(words);
  const [lessonCount] = await db
    .select({ count: sql<number>`count(*)` })
    .from(lessons);
  const [questionCount] = await db
    .select({ count: sql<number>`count(*)` })
    .from(quizQuestions);
  const [categoryCount] = await db
    .select({ count: sql<number>`count(*)` })
    .from(categories);

  return {
    words: Number(wordCount.count),
    lessons: Number(lessonCount.count),
    questions: Number(questionCount.count),
    categories: Number(categoryCount.count),
  };
}
