import { asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { quizResults, wordProgress, words } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";

export const dynamic = "force-dynamic";

type ProgressBody = {
  learnerId?: unknown;
  wordId?: unknown;
  status?: unknown;
  score?: unknown;
  total?: unknown;
};

export async function GET(request: Request) {
  try {
    await ensureSeeded();

    const { searchParams } = new URL(request.url);
    const learnerId = (searchParams.get("learner") ?? "guest").slice(0, 64);

    const totalWords = Number(
      (
        await db.select({ count: sql<number>`count(*)` }).from(words)
      )[0].count,
    );

    const progressRows = await db
      .select({
        status: wordProgress.status,
        count: sql<number>`count(*)`,
      })
      .from(wordProgress)
      .where(eq(wordProgress.learnerId, learnerId))
      .groupBy(wordProgress.status);

    const mastered =
      Number(progressRows.find((row) => row.status === "mastered")?.count ?? 0) ||
      0;
    const review =
      Number(progressRows.find((row) => row.status === "review")?.count ?? 0) || 0;

    const results = await db
      .select({
        score: quizResults.score,
        total: quizResults.total,
        createdAt: quizResults.createdAt,
      })
      .from(quizResults)
      .where(eq(quizResults.learnerId, learnerId))
      .orderBy(asc(quizResults.createdAt));

    const bestScore = results.reduce(
      (best, row) => Math.max(best, row.total ? row.score / row.total : 0),
      0,
    );

    return Response.json({
      learnerId,
      totalWords,
      mastered,
      review,
      attempts: results.length,
      bestScore: Math.round(bestScore * 100),
      lastScore:
        results.length > 0
          ? Math.round(
              (results[results.length - 1].score /
                Math.max(1, results[results.length - 1].total)) *
                100,
            )
          : null,
    });
  } catch (error) {
    console.error("progress GET failed", error);
    return Response.json({ error: "database unavailable" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    await ensureSeeded();

    const body = (await request.json()) as ProgressBody;
    const learnerId =
      typeof body.learnerId === "string" && body.learnerId.length > 0
        ? body.learnerId.slice(0, 64)
        : "guest";

    if (typeof body.score === "number" && typeof body.total === "number") {
      const [row] = await db
        .insert(quizResults)
        .values({
          learnerId,
          score: Math.max(0, Math.round(body.score)),
          total: Math.max(1, Math.round(body.total)),
        })
        .returning({ id: quizResults.id });

      return Response.json({ ok: true, kind: "quiz", id: row.id });
    }

    if (typeof body.wordId === "number" && typeof body.status === "string") {
      const status = body.status === "mastered" ? "mastered" : "review";
      await db
        .insert(wordProgress)
        .values({ learnerId, wordId: body.wordId, status })
        .onConflictDoUpdate({
          target: [wordProgress.learnerId, wordProgress.wordId],
          set: { status, updatedAt: new Date() },
        });

      return Response.json({ ok: true, kind: "word", status });
    }

    return Response.json({ error: "invalid payload" }, { status: 400 });
  } catch (error) {
    console.error("progress POST failed", error);
    return Response.json({ error: "database unavailable" }, { status: 500 });
  }
}


