import { asc } from "drizzle-orm";
import { db } from "@/db";
import { quizQuestions } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { Quiz, type QuizQuestion } from "@/components/Quiz";

export const dynamic = "force-dynamic";

export default async function QuizPage() {
  await ensureSeeded();
  const rows = await db
    .select()
    .from(quizQuestions)
    .orderBy(asc(quizQuestions.sortOrder));

  const questions: QuizQuestion[] = rows.map((row) => ({
    id: row.id,
    promptAr: row.promptAr,
    promptEn: row.promptEn,
    options: Array.isArray(row.options) ? row.options : [],
    correctIndex: row.correctIndex,
    explainAr: row.explainAr,
    topic: row.topic,
  }));

  return (
    <div className="paper-grain">
      <section className="border-b-2 border-ink">
        <div className="mx-auto max-w-[1180px] px-5 pt-14 pb-12 sm:px-8">
          <p className="tracked font-en text-[10px] text-vermilion">
            Quiz · Progress saved to your profile
          </p>
          <h1 className="mt-4 text-[clamp(2.8rem,8vw,5.6rem)] font-black leading-[0.98]">
            الاختبار
          </h1>
          <p className="mt-5 max-w-[58ch] text-[18px] font-extralight leading-[2] text-ink/80">
            اثنا عشر سؤالًا تغطي المفردات والقواعد والترجمة. بعد كل إجابة يظهر
            الشرح مباشرة، وفي النهاية تحصل على نتيجتك — وتُحفظ لتراها في زيارتك
            القادمة.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[900px] px-5 py-14 sm:px-8">
        <Quiz questions={questions} />
      </section>
    </div>
  );
}
