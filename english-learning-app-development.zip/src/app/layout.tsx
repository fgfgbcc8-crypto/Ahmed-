import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { SiteFooter } from "@/components/SiteFooter";
import { SiteHeader } from "@/components/SiteHeader";

export const metadata: Metadata = {
  title: "لُغَتي — تعلّم الإنجليزية بالعربية",
  description:
    "مقرر تفاعلي لتعلّم اللغة الإنجليزية للمتحدثين بالعربية: 30 كلمة عملية، 6 دروس قواعد، واختبار يقيس تقدّمك — بتصميم كراسة مدرسية.",
};

const FONT_URL =
  "https://fonts.googleapis.com/css2?family=Tajawal:wght@200;300;400;500;700;800;900&family=Fraunces:ital,opsz,wght@0,9..144,300..900;1,9..144,300..900&display=swap";

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="stylesheet" href={FONT_URL} />
      </head>
      <body className="min-h-screen bg-paper text-ink antialiased">
        <SiteHeader />
        <main>{children}</main>
        <SiteFooter />
      </body>
    </html>
  );
}
