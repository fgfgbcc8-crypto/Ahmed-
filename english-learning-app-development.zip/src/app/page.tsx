import Image from "next/image";
import Link from "next/link";
import { asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { categories, lessons, words } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { getCourseStats } from "@/lib/stats";
import { Reveal } from "@/components/Reveal";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  await ensureSeeded();
  const stats = await getCourseStats();

  const chapterRows = await db
    .select({
      id: categories.id,
      slug: categories.slug,
      titleAr: categories.titleAr,
      titleEn: categories.titleEn,
      descriptionAr: categories.descriptionAr,
      count: sql<number>`count(${words.id})`,
    })
    .from(categories)
    .leftJoin(words, eq(words.categoryId, categories.id))
    .groupBy(categories.id)
    .orderBy(asc(categories.sortOrder));

  const [featured] = await db
    .select()
    .from(lessons)
    .orderBy(asc(lessons.sortOrder))
    .limit(1);

  return (
    <>
      {/* ---------------------------------------------------------- hero */}
      <section className="paper-grain relative overflow-hidden border-b-2 border-ink">
        <div className="mx-auto grid max-w-[1180px] gap-10 px-5 pt-14 pb-0 sm:px-8 lg:grid-cols-[1.05fr_0.95fr] lg:gap-14 lg:pt-20">
          <div className="relative z-10 pb-14 lg:pb-24">
            <p className="tracked font-en text-[10px] font-medium text-vermilion">
              A1 → B1 · Arabic-first English course
            </p>

            <h1 className="mt-6 text-[clamp(3.1rem,10vw,7.2rem)] font-black leading-[0.92] tracking-[-0.02em] text-ink">
              تعلّم
              <br />
              الإنجليزية
              <span className="relative mt-2 block">
                <span className="ink-underline font-extralight">
                  من أول كلمة
                </span>
              </span>
            </h1>

            <p className="mt-7 max-w-[52ch] text-[19px] font-extralight leading-[1.95] text-ink/80">
              مقرّر مرتّب ككرّاسة مدرسية:{" "}
              <strong className="font-bold text-ink">{stats.words} كلمة</strong>{" "}
              تُستعمل فعلًا في المطعم والمطار والعمل،{" "}
              <strong className="font-bold text-ink">
                {stats.lessons} دروس قواعد
              </strong>{" "}
              مشروحة بالعربية بلا تعقيد، ثم{" "}
              <strong className="font-bold text-ink">اختبار قصير</strong> يقيس
              تقدّمك ويحفظ نتيجتك.
            </p>

            <div className="mt-9 flex flex-wrap items-center gap-x-8 gap-y-4">
              <Link
                href="/vocabulary"
                className="group inline-flex items-center gap-3 bg-ink px-7 py-4 text-lg font-bold text-paper transition-colors hover:bg-vermilion"
              >
                ابدأ من المفردات
                <span
                  aria-hidden
                  className="font-en transition-transform duration-300 group-hover:-translate-x-1"
                >
                  ←
                </span>
              </Link>
              <Link
                href="/quiz"
                className="border-b-2 border-vermilion pb-1 text-lg font-medium text-ink transition-colors hover:text-vermilion"
              >
                أو ابدأ الاختبار مباشرة
              </Link>
            </div>

            <dl className="mt-12 flex flex-wrap items-end gap-x-10 gap-y-6 border-t border-rule pt-7">
              {[
                { value: stats.words, label: "كلمة", latin: "Words" },
                { value: stats.lessons, label: "درس قواعد", latin: "Grammar" },
                { value: stats.questions, label: "سؤال", latin: "Questions" },
                { value: "30", label: "دقيقة يوميًا", latin: "A day" },
              ].map((item) => (
                <div key={item.latin}>
                  <dd className="font-en text-[2.6rem] font-light leading-none text-ink">
                    {item.value}
                  </dd>
                  <dt className="mt-1.5 text-sm font-medium text-taupe">
                    {item.label}
                    <span className="tracked ms-2 font-en text-[9px] text-taupe/70">
                      {item.latin}
                    </span>
                  </dt>
                </div>
              ))}
            </dl>
          </div>

          <div className="relative -mx-5 min-h-[380px] sm:-mx-8 lg:mx-0 lg:-me-10 lg:min-h-[620px]">
            <Image
              src="/images/hero-desk.jpg"
              alt="كرّاسة لغة مفتوحة وبطاقات مفردات وقلم على مكتب"
              fill
              priority
              sizes="(max-width: 1024px) 100vw, 45vw"
              className="object-cover"
            />
            <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(to_left,rgba(244,236,221,0.94),rgba(244,236,221,0.18)_36%,transparent_66%)]" />
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(120%_90%_at_70%_20%,transparent_35%,rgba(27,43,74,0.16))]" />
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------ daily plan */}
      <section className="bg-ink text-paper">
        <div className="mx-auto grid max-w-[1180px] gap-px px-5 sm:grid-cols-3 sm:px-8">
          {[
            {
              n: "01",
              title: "عشر كلمات",
              latin: "Ten words",
              body: "بطاقة تنقلب: الإنجليزية أولاً، ثم المعنى والنطق بالحروف العربية.",
            },
            {
              n: "02",
              title: "قاعدتان",
              latin: "Two rules",
              body: "قاعدة مشروحة بالعربية مع مثال صحيح وخطأ شائع مُعلَّم بالأحمر.",
            },
            {
              n: "03",
              title: "اختبار قصير",
              latin: "A short quiz",
              body: "اثنا عشر سؤالًا، تصحيح فوري، ونتيجة تُحفظ لترى تقدّمك.",
            },
          ].map((step, index) => (
            <Reveal key={step.n} delay={index * 0.08}>
              <div className="h-full border-b border-paper/15 px-1 py-10 sm:px-8">
                <p className="font-en text-5xl font-light text-vermilion">
                  {step.n}
                </p>
                <h3 className="mt-5 text-2xl font-bold">{step.title}</h3>
                <p className="tracked mt-1 font-en text-[9px] text-paper/45">
                  {step.latin}
                </p>
                <p className="mt-4 max-w-[34ch] font-extralight leading-[1.95] text-paper/75">
                  {step.body}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ---------------------------------------------------- chapter index */}
      <section className="paper-grain mx-auto max-w-[1180px] px-5 pt-20 sm:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6 border-b-2 border-ink pb-6">
          <div>
            <p className="tracked font-en text-[10px] text-taupe">
              Contents · Table of chapters
            </p>
            <h2 className="mt-3 text-[clamp(2.2rem,5.5vw,3.6rem)] font-black leading-tight">
              فهرس المفردات
            </h2>
          </div>
          <p className="max-w-[38ch] text-[17px] font-extralight leading-[1.9] text-ink/75">
            ستة فصول، كل فصل يغطي موقفًا حقيقيًا. اختر الفصل الذي تحتاجه أولًا،
            وذاكّر البطاقات حتى تظهر لك بترتيب عشوائي.
          </p>
        </div>

        <ul>
          {chapterRows.map((chapter, index) => (
            <Reveal key={chapter.id} delay={index * 0.05}>
              <li>
                <Link
                  href={`/vocabulary?category=${chapter.slug}`}
                  className="group grid grid-cols-[auto_1fr] items-start gap-x-6 border-b border-rule py-8 transition-colors hover:bg-card sm:grid-cols-[7rem_1fr_auto] sm:gap-x-10"
                >
                  <span className="margin-numeral text-[3.4rem] transition-colors duration-300 group-hover:text-vermilion sm:text-[5.2rem]">
                    {String(index + 1).padStart(2, "0")}
                  </span>

                  <div>
                    <h3 className="text-[clamp(1.6rem,3.6vw,2.35rem)] font-bold leading-tight text-ink">
                      {chapter.titleAr}
                    </h3>
                    <p className="tracked mt-1.5 font-en text-[10px] text-vermilion">
                      {chapter.titleEn}
                    </p>
                    <p className="mt-3 max-w-[52ch] font-extralight leading-[1.9] text-ink/70">
                      {chapter.descriptionAr}
                    </p>
                  </div>

                  <div className="col-span-2 mt-4 flex items-center gap-3 sm:col-span-1 sm:mt-0 sm:flex-col sm:items-end sm:gap-1">
                    <span className="font-en text-3xl font-light text-ink">
                      {Number(chapter.count)}
                    </span>
                    <span className="text-sm text-taupe">كلمة</span>
                    <span className="mt-2 inline-flex items-center gap-2 text-sm font-bold text-vermilion opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                      ابدأ الفصل
                      <span aria-hidden>←</span>
                    </span>
                  </div>
                </Link>
              </li>
            </Reveal>
          ))}
        </ul>
      </section>

      {/* -------------------------------------------------- featured lesson */}
      {featured ? (
        <section className="mx-auto mt-24 max-w-[1180px] px-5 sm:px-8">
          <div className="grid items-stretch gap-0 border-2 border-ink lg:grid-cols-[0.82fr_1.18fr]">
            <div className="relative min-h-[320px] lg:min-h-[520px]">
              <Image
                src="/images/inkwell.jpg"
                alt="محبرة زجاجية وقلم حبر وبطاقات مرتّبة"
                fill
                sizes="(max-width: 1024px) 100vw, 38vw"
                className="object-cover"
              />
              <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(to_top,rgba(27,43,74,0.42),transparent_55%)]" />
              <p className="tracked absolute bottom-5 start-5 font-en text-[10px] text-paper">
                Chapter of the day
              </p>
            </div>

            <div className="ruled bg-card px-6 py-12 sm:px-12">
              <p className="tracked font-en text-[10px] text-vermilion">
                Grammar · {featured.level}
              </p>
              <h2 className="mt-4 text-[clamp(2.1rem,4.6vw,3.2rem)] font-black leading-tight">
                {featured.titleAr}
              </h2>
              <p className="mt-1 font-en text-lg font-light italic text-taupe">
                {featured.titleEn}
              </p>

              <p className="mt-6 max-w-[52ch] text-[18px] font-extralight leading-[2] text-ink/85">
                {featured.ruleAr}
              </p>

              <div className="mt-7 border-s-2 border-ink ps-5">
                <p className="tracked font-en text-[9px] text-taupe">
                  Structure
                </p>
                <p className="mt-2 font-en text-xl leading-relaxed text-ink">
                  {featured.structureEn}
                </p>
              </div>

              <div className="mt-8 border-s-4 border-vermilion bg-vermilion/[0.07] px-5 py-4">
                <p className="text-sm font-bold text-vermilion">خطأ شائع</p>
                <p className="mt-2 font-en text-lg text-ink line-through decoration-vermilion/70 decoration-2">
                  {featured.mistakeWrongEn}
                </p>
                <p className="mt-1 font-en text-lg font-semibold text-forest">
                  {featured.mistakeRightEn}
                </p>
                <p className="mt-2 font-extralight leading-[1.9] text-ink/75">
                  {featured.mistakeAr}
                </p>
              </div>

              <Link
                href="/lessons"
                className="mt-9 inline-flex items-center gap-3 border-b-2 border-ink pb-1 text-lg font-bold text-ink transition-colors hover:border-vermilion hover:text-vermilion"
              >
                اقرأ دروس القواعد كلها
                <span aria-hidden>←</span>
              </Link>
            </div>
          </div>
        </section>
      ) : null}
    </>
  );
}
