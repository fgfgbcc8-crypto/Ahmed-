import Link from "next/link";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { categories, words } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { Flashcards, type CardWord } from "@/components/Flashcards";

export const dynamic = "force-dynamic";

type SearchParams = Promise<{ category?: string }>;

export default async function VocabularyPage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  await ensureSeeded();
  const params = await searchParams;
  const activeSlug = params.category ?? "restaurant";

  const chapterRows = await db
    .select({
      id: categories.id,
      slug: categories.slug,
      titleAr: categories.titleAr,
      titleEn: categories.titleEn,
    })
    .from(categories)
    .orderBy(asc(categories.sortOrder));

  const activeChapter =
    chapterRows.find((chapter) => chapter.slug === activeSlug) ?? chapterRows[0];

  const wordRows = await db
    .select()
    .from(words)
    .where(eq(words.categoryId, activeChapter.id))
    .orderBy(asc(words.id));

  const cards: CardWord[] = wordRows.map((word) => ({
    id: word.id,
    en: word.en,
    ar: word.ar,
    transliteration: word.transliteration,
    partOfSpeech: word.partOfSpeech,
    exampleEn: word.exampleEn,
    exampleAr: word.exampleAr,
    categoryTitle: activeChapter.titleAr,
  }));

  return (
    <div className="paper-grain">
      {/* chapter header */}
      <section className="border-b-2 border-ink">
        <div className="mx-auto max-w-[1180px] px-5 pt-14 pb-10 sm:px-8">
          <p className="tracked font-en text-[10px] text-vermilion">
            Vocabulary · Flashcards
          </p>
          <h1 className="mt-4 text-[clamp(2.8rem,8vw,5.6rem)] font-black leading-[0.98]">
            بطاقات المفردات
          </h1>
          <p className="mt-5 max-w-[58ch] text-[18px] font-extralight leading-[2] text-ink/80">
            كل بطاقة تحمل كلمة إنجليزية. حاول أن تتذكّر المعنى قبل قلبها، ثم
            اختر: أتقنتها أو أحتاج مراجعة. تُحفظ إجاباتك على الخادم لتتابع تقدّمك.
          </p>

          <nav className="mt-8 flex flex-wrap gap-2.5">
            {chapterRows.map((chapter) => {
              const active = chapter.slug === activeChapter.slug;
              return (
                <Link
                  key={chapter.slug}
                  href={`/vocabulary?category=${chapter.slug}`}
                  className={`px-4 py-2.5 text-[15px] transition-colors ${
                    active
                      ? "bg-ink font-bold text-paper"
                      : "border border-rule bg-card text-ink hover:border-ink"
                  }`}
                >
                  {chapter.titleAr}
                </Link>
              );
            })}
          </nav>
        </div>
      </section>

      {/* flashcards */}
      <section className="mx-auto max-w-[1000px] px-5 py-14 sm:px-8">
        <Flashcards
          words={cards}
          chapterLabel={activeChapter.titleEn.toUpperCase()}
        />
      </section>

      {/* word index table */}
      <section className="mx-auto max-w-[1180px] px-5 pb-8 sm:px-8">
        <div className="flex items-end justify-between gap-6 border-b-2 border-ink pb-4">
          <h2 className="text-[clamp(1.8rem,4vw,2.6rem)] font-black">
            فهرس الفصل
          </h2>
          <p className="tracked font-en text-[10px] text-taupe">
            {activeChapter.titleEn} · {cards.length} words
          </p>
        </div>

        <table className="w-full border-collapse text-start">
          <thead>
            <tr className="tracked border-b border-rule text-[9px] text-taupe">
              <th className="py-3 text-start font-medium">Word</th>
              <th className="py-3 text-start font-medium">المعنى</th>
              <th className="py-3 text-start font-medium">النطق</th>
              <th className="hidden py-3 text-start font-medium sm:table-cell">
                المثال
              </th>
            </tr>
          </thead>
          <tbody>
            {cards.map((card) => (
              <tr
                key={card.id}
                className="border-b border-rule align-top transition-colors hover:bg-card"
              >
                <td className="py-4 pe-4">
                  <span className="font-en text-xl text-ink">{card.en}</span>
                  <span className="tracked ms-2 font-en text-[9px] text-taupe">
                    {card.partOfSpeech}
                  </span>
                </td>
                <td className="py-4 pe-4 text-lg font-medium">{card.ar}</td>
                <td className="py-4 pe-4 text-taupe">{card.transliteration}</td>
                <td className="hidden py-4 font-en text-[15px] italic text-ink/75 sm:table-cell">
                  {card.exampleEn}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </div>
  );
}
