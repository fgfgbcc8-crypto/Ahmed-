import Image from "next/image";
import Link from "next/link";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { lessons } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { Reveal } from "@/components/Reveal";

export const dynamic = "force-dynamic";

export default async function LessonsPage() {
  await ensureSeeded();
  const lessonRows = await db
    .select()
    .from(lessons)
    .orderBy(asc(lessons.sortOrder));

  return (
    <div className="paper-grain">
      <section className="border-b-2 border-ink">
        <div className="mx-auto max-w-[1180px] px-5 pt-14 pb-12 sm:px-8">
          <div className="grid gap-10 lg:grid-cols-[1.25fr_0.75fr] lg:items-end">
            <div>
              <p className="tracked font-en text-[10px] text-vermilion">
                Grammar · {lessonRows.length} lessons
              </p>
              <h1 className="mt-4 text-[clamp(2.8rem,8vw,5.6rem)] font-black leading-[0.98]">
                القواعد
                <span className="block font-extralight text-ink/70">
                  بلا تعقيد
                </span>
              </h1>
              <p className="mt-6 max-w-[56ch] text-[18px] font-extralight leading-[2] text-ink/80">
                كل درس يتبع نفس الترتيب: القاعدة أولًا، ثم شكل الجملة، ثم ثلاثة
                أمثلة حقيقية، وفي النهاية الخطأ الشائع الذي يقع فيه المتعلّم
                العربي — مُعلَّم بالأحمر كتصحيح المعلّم على الكرّاسة.
              </p>
            </div>

            <div className="relative h-[260px] border-2 border-ink lg:h-[320px]">
              <Image
                src="/images/typecase.jpg"
                alt="خزانة حروف طباعة معدنية"
                fill
                sizes="(max-width: 1024px) 100vw, 32vw"
                className="object-cover"
              />
              <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(to_top,rgba(27,43,74,0.55),transparent_60%)]" />
              <p className="tracked absolute bottom-4 start-4 font-en text-[10px] text-paper">
                Rules set in ink
              </p>
            </div>
          </div>
        </div>
      </section>

      {lessonRows.map((lesson, index) => {
        const examples = Array.isArray(lesson.examples) ? lesson.examples : [];
        return (
          <section
            key={lesson.slug}
            className="border-b border-rule transition-colors hover:bg-card/60"
          >
            <div className="mx-auto grid max-w-[1180px] gap-8 px-5 py-16 sm:px-8 lg:grid-cols-[8rem_1fr] lg:gap-14">
              <div className="self-start lg:sticky lg:top-28">
                <p className="margin-numeral text-[4.2rem] lg:text-[6.4rem]">
                  {String(index + 1).padStart(2, "0")}
                </p>
                <p className="tracked mt-3 inline-block border border-ink px-2.5 py-1 font-en text-[10px] text-ink">
                  Level {lesson.level}
                </p>
                <p className="tracked mt-3 font-en text-[9px] leading-relaxed text-taupe">
                  {lesson.titleEn}
                </p>
              </div>

              <Reveal>
                <div>
                  <h2 className="text-[clamp(2.1rem,5vw,3.3rem)] font-black leading-tight">
                    {lesson.titleAr}
                  </h2>
                  <p className="mt-1 font-en text-xl font-light italic text-vermilion">
                    {lesson.titleEn}
                  </p>

                  <p className="mt-5 max-w-[58ch] text-[18px] font-extralight leading-[2] text-ink/85">
                    {lesson.summaryAr}
                  </p>

                  <div className="mt-8 grid gap-6 md:grid-cols-[1.15fr_0.85fr]">
                    <div className="border-s-2 border-ink ps-5">
                      <p className="tracked font-en text-[9px] text-taupe">
                        The rule · القاعدة
                      </p>
                      <p className="mt-3 max-w-[52ch] text-[17px] leading-[2] text-ink">
                        {lesson.ruleAr}
                      </p>
                    </div>

                    <div className="bg-ink px-6 py-6 text-paper">
                      <p className="tracked font-en text-[9px] text-paper/50">
                        Structure
                      </p>
                      <p className="mt-3 font-en text-[17px] leading-[1.9]">
                        {lesson.structureEn}
                      </p>
                    </div>
                  </div>

                  <ol className="mt-10 space-y-5">
                    {examples.map((example, exampleIndex) => (
                      <li
                        key={`${lesson.slug}-${exampleIndex}`}
                        className="flex gap-5 border-b border-rule pb-5"
                      >
                        <span className="font-en text-2xl font-light text-vermilion">
                          {String(exampleIndex + 1).padStart(2, "0")}
                        </span>
                        <div>
                          <p className="font-en text-[clamp(1.15rem,2.6vw,1.55rem)] leading-snug text-ink">
                            {example.en}
                          </p>
                          <p className="mt-1.5 font-extralight text-ink/70">
                            {example.ar}
                          </p>
                        </div>
                      </li>
                    ))}
                  </ol>

                  <div className="mt-9 border-s-4 border-vermilion bg-vermilion/[0.07] px-6 py-5">
                    <p className="text-sm font-bold text-vermilion">
                      خطأ شائع
                    </p>
                    <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2">
                      <p className="font-en text-xl text-ink line-through decoration-vermilion decoration-2">
                        {lesson.mistakeWrongEn}
                      </p>
                      <span aria-hidden className="text-vermilion">
                        ←
                      </span>
                      <p className="font-en text-xl font-semibold text-forest">
                        {lesson.mistakeRightEn}
                      </p>
                    </div>
                    <p className="mt-3 max-w-[56ch] font-extralight leading-[1.95] text-ink/75">
                      {lesson.mistakeAr}
                    </p>
                  </div>
                </div>
              </Reveal>
            </div>
          </section>
        );
      })}

      <section className="mx-auto max-w-[1180px] px-5 py-16 sm:px-8">
        <div className="flex flex-wrap items-center justify-between gap-6 border-2 border-ink bg-card px-8 py-10">
          <div>
            <p className="tracked font-en text-[10px] text-vermilion">
              Ready?
            </p>
            <h2 className="mt-3 text-[clamp(1.9rem,4vw,2.8rem)] font-black">
              اختبر نفسك في القواعد والمفردات
            </h2>
          </div>
          <Link
            href="/quiz"
            className="inline-flex items-center gap-3 bg-ink px-7 py-4 text-lg font-bold text-paper transition-colors hover:bg-vermilion"
          >
            ابدأ الاختبار
            <span aria-hidden>←</span>
          </Link>
        </div>
      </section>
    </div>
  );
}
