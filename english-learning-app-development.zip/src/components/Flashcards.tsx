"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { getLearnerId } from "@/lib/learner";

export type CardWord = {
  id: number;
  en: string;
  ar: string;
  transliteration: string;
  partOfSpeech: string;
  exampleEn: string;
  exampleAr: string;
  categoryTitle: string;
};

type FlashcardsProps = {
  words: CardWord[];
  chapterLabel: string;
};

export function Flashcards({ words, chapterLabel }: FlashcardsProps) {
  const reduced = useReducedMotion();
  const [order, setOrder] = useState<number[]>(() =>
    words.map((_, index) => index),
  );
  const [position, setPosition] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [marks, setMarks] = useState<Record<number, "mastered" | "review">>({});
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setOrder(words.map((_, index) => index));
    setPosition(0);
    setFlipped(false);
    setMarks({});
  }, [words]);

  const current = words[order[position] ?? 0];

  const masteredCount = useMemo(
    () => Object.values(marks).filter((value) => value === "mastered").length,
    [marks],
  );

  const go = useCallback(
    (step: number) => {
      setFlipped(false);
      setSaved(false);
      setPosition((prev) => {
        const next = prev + step;
        if (next < 0) return words.length - 1;
        if (next >= words.length) return 0;
        return next;
      });
    },
    [words.length],
  );

  const shuffle = useCallback(() => {
    setOrder((prev) => {
      const next = [...prev];
      for (let i = next.length - 1; i > 0; i -= 1) {
        const j = Math.floor(Math.random() * (i + 1));
        [next[i], next[j]] = [next[j], next[i]];
      }
      return next;
    });
    setPosition(0);
    setFlipped(false);
    setSaved(false);
  }, []);

  const mark = useCallback(
    async (status: "mastered" | "review") => {
      if (!current) return;
      setMarks((prev) => ({ ...prev, [current.id]: status }));
      setSaved(true);
      try {
        await fetch("/api/progress", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            learnerId: getLearnerId(),
            wordId: current.id,
            status,
          }),
        });
      } catch {
        // progress is a bonus — never block the learner
      }
      window.setTimeout(() => go(1), 260);
    },
    [current, go],
  );

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "ArrowLeft") go(1);
      if (event.key === "ArrowRight") go(-1);
      if (event.key === " " || event.key === "Enter") {
        event.preventDefault();
        setFlipped((prev) => !prev);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [go]);

  if (!current) {
    return (
      <p className="border border-rule bg-card px-6 py-10 text-center text-taupe">
        لا توجد كلمات في هذا الفصل بعد.
      </p>
    );
  }

  const progress = ((position + 1) / words.length) * 100;

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <p className="tracked font-en text-[10px] text-taupe">
          {chapterLabel} · {String(position + 1).padStart(2, "0")}/
          {String(words.length).padStart(2, "0")}
        </p>
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={shuffle}
            className="border border-ink px-4 py-2 text-sm font-medium text-ink transition-colors hover:bg-ink hover:text-paper"
          >
            ترتيب عشوائي
          </button>
          <button
            type="button"
            onClick={() => setFlipped((prev) => !prev)}
            className="border border-vermilion px-4 py-2 text-sm font-medium text-vermilion transition-colors hover:bg-vermilion hover:text-paper"
          >
            {flipped ? "إخفاء المعنى" : "أظهر المعنى"}
          </button>
        </div>
      </div>

      <div className="mt-3 h-[3px] w-full bg-rule">
        <div
          className="h-full bg-vermilion transition-[width] duration-500"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className="flip-scene mt-8">
        <div
          role="button"
          tabIndex={0}
          aria-label="اقلب البطاقة لرؤية المعنى"
          onClick={() => setFlipped((prev) => !prev)}
          onKeyDown={(event) => {
            if (event.key === "Enter") setFlipped((prev) => !prev);
          }}
          className={`flip-inner ${flipped ? "is-flipped" : ""} h-[430px] cursor-pointer sm:h-[470px]`}
        >
          {/* front */}
          <div className="flip-face border-2 border-ink bg-card shadow-[10px_10px_0_rgba(27,43,74,0.12)]">
            <div className="ruled flex h-full flex-col justify-between px-7 py-8 sm:px-12">
              <div className="flex items-start justify-between gap-4">
                <p className="tracked font-en text-[10px] text-vermilion">
                  {current.partOfSpeech}
                </p>
                <p className="tracked font-en text-[10px] text-taupe">
                  {current.categoryTitle}
                </p>
              </div>

              <div>
                <p className="font-en text-[clamp(2.7rem,9vw,5.6rem)] font-light leading-[1.02] text-ink">
                  {current.en}
                </p>
                <p className="mt-4 text-lg font-extralight text-taupe">
                  اضغط البطاقة لرؤية المعنى
                </p>
              </div>

              <p className="tracked font-en text-[9px] text-taupe/80">
                Lughaty · word card
              </p>
            </div>
          </div>

          {/* back */}
          <div className="flip-back flip-face border-2 border-ink bg-ink text-paper shadow-[10px_10px_0_rgba(27,43,74,0.12)]">
            <div className="flex h-full flex-col justify-between px-7 py-8 sm:px-12">
              <div>
                <p className="tracked font-en text-[10px] text-paper/50">
                  Meaning · المعنى
                </p>
                <p className="mt-3 text-[clamp(2.1rem,6.2vw,3.4rem)] font-black leading-[1.25]">
                  {current.ar}
                </p>
                <p className="mt-3 inline-block border-b-2 border-vermilion pb-1 text-xl font-light text-paper/85">
                  {current.transliteration}
                </p>
              </div>

              <div>
                <p className="font-en text-[clamp(1.15rem,3vw,1.65rem)] font-normal italic leading-snug text-paper">
                  {current.exampleEn}
                </p>
                <p className="mt-2 font-extralight leading-[1.9] text-paper/70">
                  {current.exampleAr}
                </p>
              </div>

              <p className="tracked font-en text-[9px] text-paper/45">
                {current.en} · {current.partOfSpeech}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-7 flex flex-wrap items-center justify-between gap-5">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => go(-1)}
            className="flex h-12 w-12 items-center justify-center border border-ink text-xl text-ink transition-colors hover:bg-ink hover:text-paper"
            aria-label="البطاقة السابقة"
          >
            →
          </button>
          <button
            type="button"
            onClick={() => go(1)}
            className="flex h-12 w-12 items-center justify-center border border-ink text-xl text-ink transition-colors hover:bg-ink hover:text-paper"
            aria-label="البطاقة التالية"
          >
            ←
          </button>
          <p className="ms-2 text-sm text-taupe">
            أتقنتها في هذه الجلسة:{" "}
            <span className="font-en text-base text-ink">{masteredCount}</span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <AnimatePresence>
            {saved ? (
              <motion.span
                initial={reduced ? false : { opacity: 0, scale: 1.15, rotate: -8 }}
                animate={{ opacity: 1, scale: 1, rotate: -6 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.24 }}
                className="stamp border-2 border-forest px-3 py-1 text-sm font-bold text-forest"
              >
                تم الحفظ ✓
              </motion.span>
            ) : null}
          </AnimatePresence>

          <button
            type="button"
            onClick={() => mark("review")}
            className="border-2 border-vermilion px-6 py-3 text-base font-bold text-vermilion transition-colors hover:bg-vermilion hover:text-paper"
          >
            أحتاج مراجعة
          </button>
          <button
            type="button"
            onClick={() => mark("mastered")}
            className="bg-forest px-6 py-3 text-base font-bold text-paper transition-colors hover:bg-ink"
          >
            أتقنتها ✓
          </button>
        </div>
      </div>
    </div>
  );
}
