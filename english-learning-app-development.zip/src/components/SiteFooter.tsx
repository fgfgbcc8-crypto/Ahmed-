import Link from "next/link";

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t-2 border-ink bg-ink text-paper">
      <div className="mx-auto max-w-[1180px] px-5 py-14 sm:px-8">
        <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr]">
          <div>
            <p className="tracked font-en text-[10px] text-paper/50">
              An open Arabic-first English course
            </p>
            <p className="mt-4 max-w-[38ch] text-2xl font-extralight leading-[1.7] text-paper/90">
              مقرّر مفتوح لتعلّم الإنجليزية خطوة بخطوة — كلمات تُستعمل فعلًا،
              قواعد مشروحة بالعربية، واختبار يقيس تقدّمك.
            </p>
            <Link
              href="/quiz"
              className="mt-7 inline-flex items-center gap-2 border-b-2 border-vermilion pb-1 text-lg font-bold text-paper transition-colors hover:text-vermilion"
            >
              ابدأ الاختبار
              <span aria-hidden>←</span>
            </Link>
          </div>

          <div>
            <p className="tracked font-en text-[10px] text-paper/50">Chapters</p>
            <ul className="mt-4 space-y-2.5">
              {[
                { href: "/vocabulary", label: "المفردات — 30 كلمة" },
                { href: "/lessons", label: "القواعد — 6 دروس" },
                { href: "/quiz", label: "الاختبار — 12 سؤالًا" },
              ].map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="text-paper/80 transition-colors hover:text-vermilion"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="tracked font-en text-[10px] text-paper/50">Levels</p>
            <p className="mt-4 font-en text-5xl font-light leading-none text-paper/90">
              A1 <span className="text-vermilion">→</span> B1
            </p>
            <p className="mt-4 text-paper/70 leading-[1.9]">
              صُمّم المقرر للمبتدئين العرب، من أول كلمة حتى الجملة الكاملة
              الطبيعية.
            </p>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-2 border-t border-paper/15 pt-6 text-sm text-paper/55 sm:flex-row sm:items-center sm:justify-between">
          <p>لُغَتي — مقرّر تعلّم الإنجليزية بالعربية.</p>
          <p className="tracked font-en text-[10px]">
            Next.js · PostgreSQL · Drizzle ORM
          </p>
        </div>
      </div>
    </footer>
  );
}
