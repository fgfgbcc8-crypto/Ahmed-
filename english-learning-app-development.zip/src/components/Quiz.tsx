"use client";

import { useCallback, useEffect, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { getLearnerId } from "@/lib/learner";

export type QuizQuestion = {
  id: number;
  promptAr: string;
  promptEn: string | null;
  options: string[];
  correctIndex: number;
  explainAr: string;
  topic: string;
};

type Stats = {
  bestScore: number;
  attempts: number;
  lastScore: number | null;
};

export function Quiz({ questions }: { questions: QuizQuestion[] }) {
  const reduced = useReducedMotion();
  const [phase, setPhase] = useState<"intro" | "playing" | "done">("intro");
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);

  const total = questions.length;
  const current = questions[index];

  const loadStats = useCallback(async () => {
    try {
      const response = await fetch(
        `/api/progress?learner=${encodeURIComponent(getLearnerId())}`,
      );
      const data = (await response.json()) as {
        bestScore: number;
        attempts: number;
        lastScore: number | null;
      };
      setStats(data);
    } catch {
      setStats(null);
    }
  }, []);

  useEffect(() => {
    void loadStats();
  }, [loadStats]);

  const start = useCallback(() => {
    setPhase("playing");
    setIndex(0);
    setSelected(null);
    setScore(0);
    setAnswers([]);
  }, []);

  const choose = useCallback(
    (optionIndex: number) => {
      if (selected !== null) return;
      setSelected(optionIndex);
      setAnswers((prev) => [...prev, optionIndex]);
      if (optionIndex === current?.correctIndex) {
        setScore((prev) => prev + 1);
      }
    },
    [current, selected],
  );

  const next = useCallback(async () => {
    if (index + 1 >= total) {
      setPhase("done");
      try {
        await fetch("/api/progress", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            learnerId: getLearnerId(),
            score,
            total,
          }),
        });
      } catch {
        // ignore — the learner still sees their score
      }
      void loadStats();
      return;
    }
    setIndex((prev) => prev + 1);
    setSelected(null);
  }, [index, loadStats, score, total]);

  const percent = total > 0 ? Math.round((score / total) * 100) : 0;

  if (phase === "intro") {
    return (
      <div className="border-2 border-ink bg-card px-7 py-12 sm:px-12">
        <p className="tracked font-en text-[10px] text-vermilion">
          Placement quiz · {total} questions
        </p>
        <h2 className="mt-4 text-[clamp(2rem,5vw,3.2rem)] font-black leading-tight">
          اختبار قصير يقيس مستواك
        </h2>
        <p className="mt-5 max-w-[54ch] text-[18px] font-extralight leading-[2] text-ink/80">
          {total} سؤالًا في المفردات والقواعد والترجمة. التصحيح فوري بعد كل
          إجابة مع شرح مختصر، ونتيجتك تُحفظ لتتابع تطوّرك في الزيارات القادمة.
        </p>

        <button
          type="button"
          onClick={start}
          className="mt-9 inline-flex items-center gap-3 bg-ink px-8 py-4 text-lg font-bold text-paper transition-colors hover:bg-vermilion"
        >
          ابدأ الآن
          <span aria-hidden>←</span>
        </button>

        {stats ? (
          <dl className="mt-10 flex flex-wrap gap-x-12 gap-y-5 border-t border-rule pt-7">
            <div>
              <dd className="font-en text-4xl font-light text-ink">
                {stats.bestScore}%
              </dd>
              <dt className="mt-1 text-sm text-taupe">أفضل نتيجة</dt>
            </div>
            <div>
              <dd className="font-en text-4xl font-light text-ink">
                {stats.attempts}
              </dd>
              <dt className="mt-1 text-sm text-taupe">محاولات</dt>
            </div>
            <div>
              <dd className="font-en text-4xl font-light text-ink">
                {stats.lastScore === null ? "—" : `${stats.lastScore}%`}
              </dd>
              <dt className="mt-1 text-sm text-taupe">آخر نتيجة</dt>
            </div>
          </dl>
        ) : null}
      </div>
    );
  }

  if (phase === "done") {
    return (
      <div className="border-2 border-ink bg-card px-7 py-12 sm:px-12">
        <div className="flex flex-wrap items-start justify-between gap-8">
          <div>
            <p className="tracked font-en text-[10px] text-vermilion">
              Result · النتيجة
            </p>
            <p className="mt-4 font-en text-[clamp(4.5rem,16vw,9rem)] font-light leading-[0.85] text-ink">
              {percent}
              <span className="text-vermilion">%</span>
            </p>
            <p className="mt-4 text-2xl font-bold">
              أجبت بشكل صحيح على {score} من {total} أسئلة.
            </p>
            <p className="mt-3 max-w-[48ch] font-extralight leading-[1.95] text-ink/75">
              {percent >= 80
                ? "ممتاز — لديك أساس قوي. انتقل إلى فصول المفردات الأصعب ووسّع حصيلتك."
                : percent >= 50
                  ? "جيد جدًا — راجع دروس القواعد مرة أخرى ثم أعد الاختبار."
                  : "بداية طبيعية — ابدأ ببطاقات المفردات ودرسين من القواعد، ثم عد إلى هنا."}
            </p>
          </div>

          <div className="stamp border-4 border-vermilion px-7 py-5 text-center">
            <p className="tracked font-en text-[10px] text-vermilion">
              Lughaty
            </p>
            <p className="mt-2 text-xl font-black text-vermilion">
              {score}/{total}
            </p>
            <p className="text-sm text-vermilion/80">تم التصحيح</p>
          </div>
        </div>

        <div className="mt-10 flex flex-wrap items-center gap-4">
          <button
            type="button"
            onClick={start}
            className="bg-ink px-7 py-4 text-lg font-bold text-paper transition-colors hover:bg-vermilion"
          >
            أعد الاختبار
          </button>
          <a
            href="/vocabulary"
            className="border-b-2 border-vermilion pb-1 text-lg font-medium text-ink transition-colors hover:text-vermilion"
          >
            راجع البطاقات
          </a>
          {stats ? (
            <p className="ms-auto text-taupe">
              أفضل نتيجة لك:{" "}
              <span className="font-en text-lg text-ink">{stats.bestScore}%</span>{" "}
              من {stats.attempts} محاولة
            </p>
          ) : null}
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <p className="tracked font-en text-[10px] text-taupe">
          Question {String(index + 1).padStart(2, "0")} / {total} ·{" "}
          {current?.topic}
        </p>
        <p className="text-sm text-taupe">
          الإجابات الصحيحة:{" "}
          <span className="font-en text-base text-ink">
            {score} / {answers.length}
          </span>
        </p>
      </div>

      <div className="mt-3 flex gap-1.5">
        {questions.map((question, questionIndex) => {
          const answered = questionIndex < answers.length;
          const isCorrect =
            answered && answers[questionIndex] === question.correctIndex;
          return (
            <span
              key={question.id}
              className={`h-[6px] flex-1 ${
                !answered
                  ? "bg-rule"
                  : isCorrect
                    ? "bg-forest"
                    : "bg-vermilion"
              }`}
            />
          );
        })}
      </div>

      <div className="mt-9 border-2 border-ink bg-card px-7 py-10 sm:px-11">
        <p className="tracked font-en text-[10px] text-vermilion">
          {current?.topic}
        </p>
        <h2 className="mt-4 text-[clamp(1.55rem,3.8vw,2.15rem)] font-bold leading-[1.65]">
          {current?.promptAr}
        </h2>
        {current?.promptEn ? (
          <p className="mt-3 font-en text-[clamp(1.25rem,3vw,1.85rem)] font-light italic text-ink/80">
            {current.promptEn}
          </p>
        ) : null}

        <ul className="mt-8 space-y-3">
          {current?.options.map((option, optionIndex) => {
            const isPicked = selected === optionIndex;
            const isAnswer = optionIndex === current.correctIndex;
            const revealed = selected !== null;

            let tone = "border-rule bg-paper text-ink hover:border-ink";
            if (revealed && isAnswer) {
              tone = "border-forest bg-forest/10 text-forest";
            } else if (revealed && isPicked) {
              tone = "border-vermilion bg-vermilion/10 text-vermilion";
            } else if (revealed) {
              tone = "border-rule bg-paper text-ink/45";
            }

            return (
              <li key={option}>
                <button
                  type="button"
                  onClick={() => choose(optionIndex)}
                  disabled={revealed}
                  className={`flex w-full items-center gap-4 border-2 px-5 py-4 text-start text-lg transition-colors ${tone}`}
                >
                  <span className="font-en text-sm opacity-70">
                    {String.fromCharCode(65 + optionIndex)}
                  </span>
                  <span className="font-medium">{option}</span>
                  {revealed && isAnswer ? (
                    <span className="ms-auto font-bold">إجابة صحيحة ✓</span>
                  ) : null}
                  {revealed && isPicked && !isAnswer ? (
                    <span className="ms-auto font-bold">إجابتك ✕</span>
                  ) : null}
                </button>
              </li>
            );
          })}
        </ul>

        <AnimatePresence>
          {selected !== null ? (
            <motion.div
              initial={reduced ? false : { opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.32 }}
              className="mt-8 border-s-4 border-ink bg-wash/60 px-5 py-4"
            >
              <p className="tracked font-en text-[9px] text-taupe">
                Explanation · الشرح
              </p>
              <p className="mt-2 text-[17px] leading-[1.95] text-ink">
                {current?.explainAr}
              </p>
            </motion.div>
          ) : null}
        </AnimatePresence>

        <div className="mt-9 flex items-center justify-between gap-4">
          <p className="text-sm text-taupe">
            يمكنك استخدام الأسهم للتنقل بين الأسئلة.
          </p>
          <button
            type="button"
            onClick={next}
            disabled={selected === null}
            className="inline-flex items-center gap-3 bg-ink px-7 py-3.5 text-lg font-bold text-paper transition-colors hover:bg-vermilion disabled:cursor-not-allowed disabled:bg-rule disabled:text-taupe"
          >
            {index + 1 >= total ? "اعرض النتيجة" : "السؤال التالي"}
            <span aria-hidden>←</span>
          </button>
        </div>
      </div>
    </div>
  );
}
