"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const LINKS = [
  { href: "/", label: "الغلاف", latin: "Home" },
  { href: "/vocabulary", label: "المفردات", latin: "Words" },
  { href: "/lessons", label: "القواعد", latin: "Grammar" },
  { href: "/quiz", label: "الاختبار", latin: "Quiz" },
];

export function SiteHeader() {
  const pathname = usePathname();

  return (
    <header className="sticky top-0 z-40 border-b border-rule bg-paper/95 backdrop-blur-sm">
      <div className="mx-auto flex max-w-[1180px] items-center justify-between gap-4 px-5 py-3 sm:px-8">
        <Link href="/" className="group flex items-center gap-3">
          <Monogram />
          <span className="leading-none">
            <span className="block font-ar text-xl font-black tracking-tight text-ink">
              لُغَتي
            </span>
            <span className="tracked block font-en text-[9px] font-medium text-taupe">
              Lughaty
            </span>
          </span>
        </Link>

        <nav className="flex items-center gap-1 sm:gap-2">
          {LINKS.map((link) => {
            const active =
              link.href === "/"
                ? pathname === "/"
                : pathname.startsWith(link.href);
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`relative px-2.5 py-1.5 text-[15px] transition-colors sm:px-3.5 sm:text-base ${
                  active
                    ? "font-bold text-ink"
                    : "font-normal text-taupe hover:text-ink"
                }`}
              >
                {link.label}
                <span
                  className={`absolute inset-x-2 -bottom-[3px] h-[2px] bg-vermilion transition-transform duration-300 ${
                    active ? "scale-x-100" : "scale-x-0"
                  }`}
                />
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}

function Monogram() {
  return (
    <svg
      width="38"
      height="38"
      viewBox="0 0 48 48"
      role="img"
      aria-label="شعار لُغَتي"
      className="shrink-0"
    >
      <rect x="1" y="1" width="46" height="46" rx="7" fill="#1B2B4A" />
      <path
        d="M10 34.5V15.2c0-.6.5-1.1 1.1-1 3.6.5 7 1.9 9.7 4.1v16.6c-2.7-2.1-6.1-3.5-9.7-4-.6-.1-1.1.4-1.1 1z"
        fill="#F4ECDD"
      />
      <path
        d="M38 34.5V15.2c0-.6-.5-1.1-1.1-1-3.6.5-7 1.9-9.7 4.1v16.6c2.7-2.1 6.1-3.5 9.7-4 .6-.1 1.1.4 1.1 1z"
        fill="#F4ECDD"
        opacity="0.72"
      />
      <path d="M31.6 8.5h4.2v13.4h-4.2z" fill="#C4442B" />
      <path d="M31.6 8.5l2.1 3.4 2.1-3.4z" fill="#C4442B" />
    </svg>
  );
}
