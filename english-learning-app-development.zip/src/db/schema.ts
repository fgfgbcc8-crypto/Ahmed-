import {
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 40 }).notNull().unique(),
  titleAr: text("title_ar").notNull(),
  titleEn: varchar("title_en", { length: 80 }).notNull(),
  descriptionAr: text("description_ar").notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const words = pgTable("words", {
  id: serial("id").primaryKey(),
  categoryId: integer("category_id")
    .notNull()
    .references(() => categories.id),
  en: varchar("en", { length: 60 }).notNull(),
  ar: text("ar").notNull(),
  transliteration: text("transliteration").notNull(),
  partOfSpeech: varchar("part_of_speech", { length: 24 }).notNull(),
  exampleEn: text("example_en").notNull(),
  exampleAr: text("example_ar").notNull(),
});

export const lessons = pgTable("lessons", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 60 }).notNull().unique(),
  titleAr: text("title_ar").notNull(),
  titleEn: varchar("title_en", { length: 80 }).notNull(),
  level: varchar("level", { length: 8 }).notNull(),
  summaryAr: text("summary_ar").notNull(),
  ruleAr: text("rule_ar").notNull(),
  structureEn: text("structure_en").notNull(),
  examples: jsonb("examples").$type<{ en: string; ar: string }[]>().notNull(),
  mistakeWrongEn: text("mistake_wrong_en").notNull(),
  mistakeRightEn: text("mistake_right_en").notNull(),
  mistakeAr: text("mistake_ar").notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const quizQuestions = pgTable("quiz_questions", {
  id: serial("id").primaryKey(),
  promptAr: text("prompt_ar").notNull(),
  promptEn: text("prompt_en"),
  options: jsonb("options").$type<string[]>().notNull(),
  correctIndex: integer("correct_index").notNull(),
  explainAr: text("explain_ar").notNull(),
  topic: varchar("topic", { length: 40 }).notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const wordProgress = pgTable(
  "word_progress",
  {
    id: serial("id").primaryKey(),
    learnerId: varchar("learner_id", { length: 64 }).notNull(),
    wordId: integer("word_id")
      .notNull()
      .references(() => words.id),
    status: varchar("status", { length: 12 }).notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("word_progress_learner_word").on(table.learnerId, table.wordId),
  ],
);

export const quizResults = pgTable("quiz_results", {
  id: serial("id").primaryKey(),
  learnerId: varchar("learner_id", { length: 64 }).notNull(),
  score: integer("score").notNull(),
  total: integer("total").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Category = typeof categories.$inferSelect;
export type Word = typeof words.$inferSelect;
export type Lesson = typeof lessons.$inferSelect;
export type QuizQuestion = typeof quizQuestions.$inferSelect;
export type WordProgress = typeof wordProgress.$inferSelect;
export type QuizResult = typeof quizResults.$inferSelect;
