import { sql } from "drizzle-orm";
import { db } from "@/db";
import { categories, lessons, quizQuestions, words } from "@/db/schema";

type WordSeed = {
  en: string;
  ar: string;
  transliteration: string;
  partOfSpeech: string;
  exampleEn: string;
  exampleAr: string;
};

type CategorySeed = {
  slug: string;
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  words: WordSeed[];
};

export const CATEGORY_SEEDS: CategorySeed[] = [
  {
    slug: "restaurant",
    titleAr: "في المطعم",
    titleEn: "At the Restaurant",
    descriptionAr: "كلمات الطلب والحساب والوصف، لتطلب وجبتك بالإنجليزية دون تردد.",
    words: [
      {
        en: "menu",
        ar: "قائمة الطعام",
        transliteration: "مينيو",
        partOfSpeech: "اسم",
        exampleEn: "Could I see the menu, please?",
        exampleAr: "هل يمكنني رؤية قائمة الطعام من فضلك؟",
      },
      {
        en: "bill",
        ar: "الحساب",
        transliteration: "بيل",
        partOfSpeech: "اسم",
        exampleEn: "Can we have the bill, please?",
        exampleAr: "هل يمكننا الحصول على الحساب من فضلك؟",
      },
      {
        en: "delicious",
        ar: "لذيذ",
        transliteration: "ديليشَس",
        partOfSpeech: "صفة",
        exampleEn: "This soup is delicious.",
        exampleAr: "هذا الحساء لذيذ.",
      },
      {
        en: "waiter",
        ar: "نادل",
        transliteration: "وييتر",
        partOfSpeech: "اسم",
        exampleEn: "The waiter brought us water.",
        exampleAr: "أحضر لنا النادل الماء.",
      },
      {
        en: "to order",
        ar: "يطلب",
        transliteration: "تو أوردَر",
        partOfSpeech: "فعل",
        exampleEn: "I would like to order chicken.",
        exampleAr: "أودّ أن أطلب الدجاج.",
      },
    ],
  },
  {
    slug: "airport",
    titleAr: "في المطار",
    titleEn: "At the Airport",
    descriptionAr: "مفردات السفر والحقائب والبوابات، من مكتب التسجيل حتى الوصول.",
    words: [
      {
        en: "boarding pass",
        ar: "بطاقة الصعود",
        transliteration: "بوردينغ باس",
        partOfSpeech: "اسم",
        exampleEn: "Please show your boarding pass.",
        exampleAr: "من فضلك أظهر بطاقة الصعود.",
      },
      {
        en: "luggage",
        ar: "الأمتعة",
        transliteration: "لَجِدج",
        partOfSpeech: "اسم",
        exampleEn: "My luggage is too heavy.",
        exampleAr: "أمتعتي ثقيلة جدًا.",
      },
      {
        en: "delayed",
        ar: "متأخر",
        transliteration: "ديلييد",
        partOfSpeech: "صفة",
        exampleEn: "The flight is delayed by two hours.",
        exampleAr: "الرحلة متأخرة ساعتين.",
      },
      {
        en: "gate",
        ar: "بوابة الصعود",
        transliteration: "جيت",
        partOfSpeech: "اسم",
        exampleEn: "Our gate is B12.",
        exampleAr: "بوابتنا هي B12.",
      },
      {
        en: "to arrive",
        ar: "يصل",
        transliteration: "تو أرايف",
        partOfSpeech: "فعل",
        exampleEn: "We arrive in Cairo at six.",
        exampleAr: "نصل إلى القاهرة في السادسة.",
      },
    ],
  },
  {
    slug: "verbs",
    titleAr: "الأفعال الأساسية",
    titleEn: "Core Verbs",
    descriptionAr: "الأفعال التي تتكرر في كل جملة تقريبًا، مع شكلها الصحيح مع الضمائر.",
    words: [
      {
        en: "to have",
        ar: "يملك / لديه",
        transliteration: "تو هاف",
        partOfSpeech: "فعل",
        exampleEn: "She has two brothers.",
        exampleAr: "لديها أخوان.",
      },
      {
        en: "to go",
        ar: "يذهب",
        transliteration: "تو جو",
        partOfSpeech: "فعل",
        exampleEn: "We go to school every day.",
        exampleAr: "نذهب إلى المدرسة كل يوم.",
      },
      {
        en: "to make",
        ar: "يصنع",
        transliteration: "تو ميك",
        partOfSpeech: "فعل",
        exampleEn: "He makes good coffee.",
        exampleAr: "هو يصنع قهوة جيدة.",
      },
      {
        en: "to need",
        ar: "يحتاج",
        transliteration: "تو نيد",
        partOfSpeech: "فعل",
        exampleEn: "I need more time.",
        exampleAr: "أحتاج إلى مزيد من الوقت.",
      },
      {
        en: "to understand",
        ar: "يفهم",
        transliteration: "تو أندَرستاند",
        partOfSpeech: "فعل",
        exampleEn: "Do you understand the question?",
        exampleAr: "هل تفهم السؤال؟",
      },
    ],
  },
  {
    slug: "work",
    titleAr: "في العمل",
    titleEn: "At Work",
    descriptionAr: "لغة الاجتماعات والمهام والرواتب، للعمل باللغة الإنجليزية بثقة.",
    words: [
      {
        en: "meeting",
        ar: "اجتماع",
        transliteration: "ميتينغ",
        partOfSpeech: "اسم",
        exampleEn: "The meeting starts at nine.",
        exampleAr: "يبدأ الاجتماع في التاسعة.",
      },
      {
        en: "deadline",
        ar: "الموعد النهائي",
        transliteration: "ديدلاين",
        partOfSpeech: "اسم",
        exampleEn: "The deadline is Friday.",
        exampleAr: "الموعد النهائي يوم الجمعة.",
      },
      {
        en: "salary",
        ar: "الراتب",
        transliteration: "سالَري",
        partOfSpeech: "اسم",
        exampleEn: "My salary arrives at the end of the month.",
        exampleAr: "يصلك راتبي في نهاية الشهر.",
      },
      {
        en: "colleague",
        ar: "زميل العمل",
        transliteration: "كوليج",
        partOfSpeech: "اسم",
        exampleEn: "My colleague speaks French.",
        exampleAr: "زميلي يتحدث الفرنسية.",
      },
      {
        en: "to apply",
        ar: "يتقدّم بطلب",
        transliteration: "تو أبلاي",
        partOfSpeech: "فعل",
        exampleEn: "She applied for the job.",
        exampleAr: "تقدّمت بطلب للوظيفة.",
      },
    ],
  },
  {
    slug: "feelings",
    titleAr: "المشاعر",
    titleEn: "Feelings",
    descriptionAr: "عبارات تصف حالتك وحال الآخرين، وهي أكثر ما تحتاجه في المحادثة.",
    words: [
      {
        en: "excited",
        ar: "متحمس",
        transliteration: "إكسايتد",
        partOfSpeech: "صفة",
        exampleEn: "I am excited about the trip.",
        exampleAr: "أنا متحمس للرحلة.",
      },
      {
        en: "tired",
        ar: "متعب",
        transliteration: "تايَرد",
        partOfSpeech: "صفة",
        exampleEn: "He is tired after work.",
        exampleAr: "هو متعب بعد العمل.",
      },
      {
        en: "worried",
        ar: "قلق",
        transliteration: "وَرِيد",
        partOfSpeech: "صفة",
        exampleEn: "Don't be worried about the exam.",
        exampleAr: "لا تقلق بشأن الامتحان.",
      },
      {
        en: "proud",
        ar: "فخور",
        transliteration: "برَاود",
        partOfSpeech: "صفة",
        exampleEn: "We are proud of you.",
        exampleAr: "نحن فخورون بك.",
      },
      {
        en: "to feel",
        ar: "يشعر",
        transliteration: "تو فييل",
        partOfSpeech: "فعل",
        exampleEn: "I feel better today.",
        exampleAr: "أشعر بتحسّن اليوم.",
      },
    ],
  },
  {
    slug: "everyday",
    titleAr: "اليوميات",
    titleEn: "Everyday Life",
    descriptionAr: "كلمات البيت والشارع والطقس، تفتح بها أي محادثة يومية.",
    words: [
      {
        en: "breakfast",
        ar: "الفطور",
        transliteration: "بريكفاست",
        partOfSpeech: "اسم",
        exampleEn: "I drink tea with breakfast.",
        exampleAr: "أشرب الشاي مع الفطور.",
      },
      {
        en: "neighbour",
        ar: "الجار",
        transliteration: "نيبَر",
        partOfSpeech: "اسم",
        exampleEn: "Our neighbour is very kind.",
        exampleAr: "جارنا لطيف جدًا.",
      },
      {
        en: "keys",
        ar: "المفاتيح",
        transliteration: "كيز",
        partOfSpeech: "اسم",
        exampleEn: "I can't find my keys.",
        exampleAr: "لا أستطيع أن أجد مفاتيحي.",
      },
      {
        en: "weather",
        ar: "الطقس",
        transliteration: "ويذَر",
        partOfSpeech: "اسم",
        exampleEn: "The weather is nice today.",
        exampleAr: "الطقس جميل اليوم.",
      },
      {
        en: "to borrow",
        ar: "يستعير",
        transliteration: "تو بورو",
        partOfSpeech: "فعل",
        exampleEn: "Can I borrow your pen?",
        exampleAr: "هل يمكنني استعارة قلمك؟",
      },
    ],
  },
];

type LessonSeed = {
  slug: string;
  titleAr: string;
  titleEn: string;
  level: string;
  summaryAr: string;
  ruleAr: string;
  structureEn: string;
  examples: { en: string; ar: string }[];
  mistakeWrongEn: string;
  mistakeRightEn: string;
  mistakeAr: string;
};

export const LESSON_SEEDS: LessonSeed[] = [
  {
    slug: "present-simple",
    titleAr: "المضارع البسيط",
    titleEn: "Present Simple",
    level: "A1",
    summaryAr: "زمن العادات والحقائق الثابتة، وهو أول زمن يجب أن تتقنه.",
    ruleAr: "نضيف s أو es إلى الفعل مع he / she / it فقط، أما I / you / we / they فنأخذ الفعل في صورته الأساسية.",
    structureEn: "Subject + verb (+ s / es) — I work · He works",
    examples: [
      { en: "She works in a hospital.", ar: "هي تعمل في مستشفى." },
      { en: "They play football on Fridays.", ar: "يلعبون كرة القدم أيام الجمعة." },
      { en: "I don't drink coffee at night.", ar: "أنا لا أشرب القهوة في الليل." },
    ],
    mistakeWrongEn: "He work every day.",
    mistakeRightEn: "He works every day.",
    mistakeAr: "مع he / she / it لا تنسَ إضافة s إلى الفعل — وهي أشهر خطأ يقع فيه المتعلّم العربي.",
  },
  {
    slug: "present-continuous",
    titleAr: "المضارع المستمر",
    titleEn: "Present Continuous",
    level: "A1",
    summaryAr: "لحدث يجري الآن في هذه اللحظة، أو لخطة مؤقتة في المستقبل القريب.",
    ruleAr: "am / is / are + الفعل + ing. انتبه: الفعل be وحده يتحوّل، أما الفعل الأساسي فيأخذ ing.",
    structureEn: "Subject + am / is / are + verb-ing",
    examples: [
      { en: "I am studying English now.", ar: "أنا أدرس الإنجليزية الآن." },
      { en: "They are watching a film.", ar: "هم يشاهدون فيلمًا." },
      { en: "She is cooking dinner.", ar: "هي تطبخ العشاء." },
    ],
    mistakeWrongEn: "She is study now.",
    mistakeRightEn: "She is studying now.",
    mistakeAr: "لا يكفي وجود is؛ يجب أن يأخذ الفعل صورة ing.",
  },
  {
    slug: "past-simple",
    titleAr: "الماضي البسيط",
    titleEn: "Past Simple",
    level: "A2",
    summaryAr: "لأحداث انتهت في وقت محدد في الماضي، مثل أمس أو العام الماضي.",
    ruleAr: "نضيف ed إلى الفعل المنتظم، أما الأفعال الشائعة go / see / take / come فلها صور شاذة تُحفظ.",
    structureEn: "Subject + verb-ed / past form · Did + subject + base verb?",
    examples: [
      { en: "We visited Alexandria last summer.", ar: "زرنا الإسكندرية الصيف الماضي." },
      { en: "He went to the market.", ar: "ذهب إلى السوق." },
      { en: "Did you call your mother?", ar: "هل اتصلت بأمك؟" },
    ],
    mistakeWrongEn: "Did you called her?",
    mistakeRightEn: "Did you call her?",
    mistakeAr: "بعد Did يعود الفعل إلى صورته الأساسية بدون ed.",
  },
  {
    slug: "will-vs-going-to",
    titleAr: "will أو going to",
    titleEn: "Will vs Going To",
    level: "A2",
    summaryAr: "الفرق بين القرار اللحظي والخطة المسبقة — فرق يغيّر معنى الجملة تمامًا.",
    ruleAr: "will للقرار الذي تتخذه في لحظة الكلام وللتنبؤ، و going to للخطط والنيات التي قررتها من قبل.",
    structureEn: "will + base verb · am / is / are going to + base verb",
    examples: [
      { en: "The phone is ringing — I'll answer it.", ar: "الهاتف يرنّ — سأجيب." },
      { en: "We are going to travel next month.", ar: "سنسافر الشهر القادم." },
      { en: "I think it will rain tonight.", ar: "أعتقد أن الجو ستمطر الليلة." },
    ],
    mistakeWrongEn: "I will go to the dentist tomorrow. (a plan you booked last week)",
    mistakeRightEn: "I am going to go to the dentist tomorrow.",
    mistakeAr: "الخطة التي حجزتها مسبقًا تُبنى على going to وليس will.",
  },
  {
    slug: "plural-nouns",
    titleAr: "جمع الأسماء",
    titleEn: "Plural Nouns",
    level: "A1",
    summaryAr: "قواعد الجمع الأساسية، وحالات y و f و o التي تربك الجميع.",
    ruleAr: "نضيف s للجمع، و es بعد s / sh / ch / x / o، و نحوّل y إلى ies بعد حرف ساكن، و f إلى ves في الكلمات الشائعة.",
    structureEn: "noun + s · noun + es · y → ies · f → ves",
    examples: [
      { en: "one book → two books", ar: "كتاب → كتابان" },
      { en: "one box → three boxes", ar: "صندوق → ثلاثة صناديق" },
      { en: "one city → many cities", ar: "مدينة → مدن كثيرة" },
    ],
    mistakeWrongEn: "two babys",
    mistakeRightEn: "two babies",
    mistakeAr: "عندما تسبق y حرف ساكن نحولها إلى ies وليس s.",
  },
  {
    slug: "prepositions-of-place",
    titleAr: "حروف الجر للمكان",
    titleEn: "Prepositions of Place",
    level: "A1",
    summaryAr: "in و on و at — ثلاثة حروف صغيرة تحسم هل أنت داخل الشيء أم فوقه أم عنده.",
    ruleAr: "in للفراغات المغلقة والمدن والدول، on للأسطح والأشياء المسطّحة، at للنقاط المحددة والأماكن المعيّنة.",
    structureEn: "in + room / city · on + surface · at + point",
    examples: [
      { en: "The keys are on the table.", ar: "المفاتيح على الطاولة." },
      { en: "She lives in Cairo.", ar: "هي تعيش في القاهرة." },
      { en: "We meet at the station.", ar: "نلتقي عند المحطة." },
    ],
    mistakeWrongEn: "The book is in the table.",
    mistakeRightEn: "The book is on the table.",
    mistakeAr: "الطاولة سطح، لذلك نستخدم on وليست in.",
  },
];

type QuestionSeed = {
  promptAr: string;
  promptEn: string | null;
  options: string[];
  correctIndex: number;
  explainAr: string;
  topic: string;
};

export const QUESTION_SEEDS: QuestionSeed[] = [
  {
    promptAr: "ما معنى كلمة bill في سياق المطعم؟",
    promptEn: "bill",
    options: ["قائمة الطعام", "الحساب", "النادل", "الطلب"],
    correctIndex: 1,
    explainAr: "bill تعني الحساب، أمّا قائمة الطعام فـ menu.",
    topic: "المفردات",
  },
  {
    promptAr: "أكمل الجملة بالشكل الصحيح:",
    promptEn: "She ___ in a hospital.",
    options: ["work", "works", "working", "worked"],
    correctIndex: 1,
    explainAr: "مع she في المضارع البسيط نضيف s إلى الفعل: works.",
    topic: "المضارع البسيط",
  },
  {
    promptAr: "ما الترجمة الصحيحة لجملة: My luggage is too heavy.",
    promptEn: "My luggage is too heavy.",
    options: [
      "حقيبتي صغيرة جدًا",
      "أمتعتي ثقيلة جدًا",
      "أمتعتي في المطار",
      "وزني ثقيل جدًا",
    ],
    correctIndex: 1,
    explainAr: "luggage تعني الأمتعة، و heavy تعني ثقيل.",
    topic: "الترجمة",
  },
  {
    promptAr: "اختر الفعل الصحيح بعد Did:",
    promptEn: "Did you ___ your mother?",
    options: ["called", "calling", "call", "calls"],
    correctIndex: 2,
    explainAr: "بعد Did يعود الفعل إلى صورته الأساسية: Did you call.",
    topic: "الماضي البسيط",
  },
  {
    promptAr: "ما معنى boarding pass؟",
    promptEn: "boarding pass",
    options: ["جواز السفر", "بطاقة الصعود", "تذكرة القطار", "حقائب اليد"],
    correctIndex: 1,
    explainAr: "boarding pass هي بطاقة الصعود التي تُطلب منك عند البوابة.",
    topic: "المفردات",
  },
  {
    promptAr: "أكمل الجملة:",
    promptEn: "The meeting ___ at nine.",
    options: ["start", "starts", "started", "starting"],
    correctIndex: 1,
    explainAr: "meeting مفرد غائب، والمضارع البسيط يأخذ starts.",
    topic: "المضارع البسيط",
  },
  {
    promptAr: "أي صيغة صحيحة لوصف شعورك تجاه رحلة قادمة؟",
    promptEn: "I am ___ about the trip.",
    options: ["exciting", "excited", "excite", "excites"],
    correctIndex: 1,
    explainAr: "نستخدم ed لوصف الشعور، و ing لوصف الشيء الذي يسبب الشعور.",
    topic: "المشاعر",
  },
  {
    promptAr: "ما التصحيح الصحيح للجملة الخاطئة: He work every day.",
    promptEn: "He work every day.",
    options: [
      "He working every day.",
      "He works every day.",
      "He is work every day.",
      "He worked every day.",
    ],
    correctIndex: 1,
    explainAr: "مع he نضيف s إلى الفعل في المضارع البسيط.",
    topic: "الأخطاء الشائعة",
  },
  {
    promptAr: "كلمة gate في المطار تعني:",
    promptEn: "gate",
    options: ["بوابة الصعود", "مكتب التسجيل", "المدرج", "الجواز"],
    correctIndex: 0,
    explainAr: "gate هي بوابة الصعود إلى الطائرة، وغالبًا يُكتب بجانبها رقم أو حرف.",
    topic: "المفردات",
  },
  {
    promptAr: "أكمل الجملة بالحرف الصحيح:",
    promptEn: "The keys are ___ the table.",
    options: ["in", "on", "at", "to"],
    correctIndex: 1,
    explainAr: "الطاولة سطح، لذلك نستخدم on.",
    topic: "حروف الجر",
  },
  {
    promptAr: "ما جمع كلمة city؟",
    promptEn: "city → ?",
    options: ["citys", "cities", "cites", "cityes"],
    correctIndex: 1,
    explainAr: "عندما تسبق y حرف ساكن نحوّلها إلى ies: cities.",
    topic: "الجمع",
  },
  {
    promptAr: "اختر الصيغة المناسبة لخطة حجزتها مسبقًا:",
    promptEn: "We ___ to travel next month. (a booked plan)",
    options: ["will go", "are going to go", "goes", "going"],
    correctIndex: 1,
    explainAr: "الخطة المسبقة تُبنى على going to + الفعل الأساسي.",
    topic: "will / going to",
  },
];

const DDL = [
  `CREATE TABLE IF NOT EXISTS categories (
    id serial PRIMARY KEY,
    slug varchar(40) NOT NULL UNIQUE,
    title_ar text NOT NULL,
    title_en varchar(80) NOT NULL,
    description_ar text NOT NULL,
    sort_order integer NOT NULL DEFAULT 0
  )`,
  `CREATE TABLE IF NOT EXISTS words (
    id serial PRIMARY KEY,
    category_id integer NOT NULL REFERENCES categories(id),
    en varchar(60) NOT NULL,
    ar text NOT NULL,
    transliteration text NOT NULL,
    part_of_speech varchar(24) NOT NULL,
    example_en text NOT NULL,
    example_ar text NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS lessons (
    id serial PRIMARY KEY,
    slug varchar(60) NOT NULL UNIQUE,
    title_ar text NOT NULL,
    title_en varchar(80) NOT NULL,
    level varchar(8) NOT NULL,
    summary_ar text NOT NULL,
    rule_ar text NOT NULL,
    structure_en text NOT NULL,
    examples jsonb NOT NULL,
    mistake_wrong_en text NOT NULL,
    mistake_right_en text NOT NULL,
    mistake_ar text NOT NULL,
    sort_order integer NOT NULL DEFAULT 0
  )`,
  `CREATE TABLE IF NOT EXISTS quiz_questions (
    id serial PRIMARY KEY,
    prompt_ar text NOT NULL,
    prompt_en text,
    options jsonb NOT NULL,
    correct_index integer NOT NULL,
    explain_ar text NOT NULL,
    topic varchar(40) NOT NULL,
    sort_order integer NOT NULL DEFAULT 0
  )`,
  `CREATE TABLE IF NOT EXISTS word_progress (
    id serial PRIMARY KEY,
    learner_id varchar(64) NOT NULL,
    word_id integer NOT NULL REFERENCES words(id),
    status varchar(12) NOT NULL,
    updated_at timestamp NOT NULL DEFAULT now(),
    UNIQUE (learner_id, word_id)
  )`,
  `CREATE TABLE IF NOT EXISTS quiz_results (
    id serial PRIMARY KEY,
    learner_id varchar(64) NOT NULL,
    score integer NOT NULL,
    total integer NOT NULL,
    created_at timestamp NOT NULL DEFAULT now()
  )`,
];

let seeding: Promise<void> | null = null;

async function seedAll(): Promise<void> {
  for (const statement of DDL) {
    await db.execute(sql.raw(statement));
  }

  const [{ count }] = await db
    .select({ count: sql<number>`count(*)` })
    .from(categories);
  if (Number(count) > 0) return;

  for (let c = 0; c < CATEGORY_SEEDS.length; c += 1) {
    const seed = CATEGORY_SEEDS[c];
    const [category] = await db
      .insert(categories)
      .values({
        slug: seed.slug,
        titleAr: seed.titleAr,
        titleEn: seed.titleEn,
        descriptionAr: seed.descriptionAr,
        sortOrder: c,
      })
      .returning({ id: categories.id });

    await db.insert(words).values(
      seed.words.map((word) => ({
        categoryId: category.id,
        en: word.en,
        ar: word.ar,
        transliteration: word.transliteration,
        partOfSpeech: word.partOfSpeech,
        exampleEn: word.exampleEn,
        exampleAr: word.exampleAr,
      })),
    );
  }

  await db.insert(lessons).values(
    LESSON_SEEDS.map((lesson, index) => ({
      slug: lesson.slug,
      titleAr: lesson.titleAr,
      titleEn: lesson.titleEn,
      level: lesson.level,
      summaryAr: lesson.summaryAr,
      ruleAr: lesson.ruleAr,
      structureEn: lesson.structureEn,
      examples: lesson.examples,
      mistakeWrongEn: lesson.mistakeWrongEn,
      mistakeRightEn: lesson.mistakeRightEn,
      mistakeAr: lesson.mistakeAr,
      sortOrder: index,
    })),
  );

  await db.insert(quizQuestions).values(
    QUESTION_SEEDS.map((question, index) => ({
      promptAr: question.promptAr,
      promptEn: question.promptEn,
      options: question.options,
      correctIndex: question.correctIndex,
      explainAr: question.explainAr,
      topic: question.topic,
      sortOrder: index,
    })),
  );
}

/** Idempotent: creates tables if needed and seeds content once per database. */
export async function ensureSeeded(): Promise<void> {
  if (!seeding) {
    seeding = seedAll().catch((error) => {
      seeding = null;
      throw error;
    });
  }
  await seeding;
}
